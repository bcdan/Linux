#include "Clerk.h"


double initRandomByType(double avg, double std, double min) {
    initrand();

    int i;
    int size = 1000;

    double cnt;
    double x;
    double sum = 0;
    double ssq = 0;
    cnt = (double) size;
    for (i = 0; i < size; i++) {
        x = pnrand(avg, std, min);
        sum += x;
        ssq += x * x;
    }

    avg = sum / cnt;
    return avg;
}


void setNew(double *avg, double *std, double *min) {
    *avg = AVRG_NEW;
    *std = SPRD_NEW;
    *min = MIN_NEW;
}

void setUpgrade(double *avg, double *std, double *min) {
    *avg = AVRG_UPGRADE;
    *std = SPRD_UPGRADE;
    *min = MIN_UPGRADE;
}

void setRepair(double *avg, double *std, double *min) {
    *avg = AVRG_REPAIR;
    *std = SPRD_REPAIR;
    *min = MIN_REPAIR;
}

void getRandomConstsByType(int customer_t, double *avg, double *std, double *min) {
    if (customer_t == TYPE_NEW)
        setNew(avg, std, min);
    else if (customer_t == TYPE_UPGRADE)
        setUpgrade(avg, std, min);
    else if (customer_t == TYPE_REPAIR)
        setRepair(avg, std, min);
}


void start(char *type) {
    key_t key;
    int msgRecieveID;
    int msgForwardID;
    int customer_t = atoi(type);
    key = customer_t;
    double avg;
    double std;
    double min;
    double handleTime; ///////////////////
    double countHandle = 0;///////////////
    getRandomConstsByType(customer_t, &avg, &std, &min);
    msgForwardID = msgget(QUIT, 0666 | IPC_CREAT);
    msgRecieveID = msgget(key, 0666 | IPC_CREAT);

    while (msgrcv(msgRecieveID, &message, sizeof(message), 0, 0) != -1) {
        handleTime = initRandomByType(avg, std, min);
        countHandle += handleTime;
        usleep(handleTime);
        message.msgType = 1;
        msgsnd(msgForwardID, &message, sizeof(message), 0);
        if (!strncmp(message.msgText, "QUIT", 4)) {
            break;
        } // todo:might cause trouble
    }
    msgctl(msgRecieveID, IPC_RMID, NULL);

}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("not enough arguments\n");
        return 0;
    }
    start(argv[1]);
    return 0;
}