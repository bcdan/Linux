
#include "Sorter.h"


double initRandomByType(double avg, double std, double min) {
    initrand();

    int i;
    int size = 1000;

    double cnt;
    double x;
    double sum = 0;
    double ssq = 0;
    cnt = (double) size;
    for (i = 0; i < size; i++) {
        x = pnrand(avg, std, min);
        sum += x;
        ssq += x * x;
    }

    avg = sum / cnt;
    return avg;
}


void setConsts(double *avg, double *std, double *min) {
    *avg = AVRG_SORT;
    *std = SPRD_SORT;
    *min = MIN_SORT;
}

int getType(char *customerType) {
    for (int i = 0; i < 4; i++) {
        if (strstr(customerType, customerTypes[i]))
            return i;
    }
    return -1;
}

void sendTerminalMsgs(struct message *m) {
    int temp;
    for (int i = 0; i < 4; i++) {
        temp = msgget(i, 0666 | IPC_CREAT);
        msgsnd(temp, m, sizeof(struct message), 0);
    }
}

void start() {
    key_t customerKey;
    int msgRecieveId = 0;
    int msgForwardID = 0;
    double avg = 0;
    double std = 0;
    double min = 0;
    double handleTime = 0; ///////////////////
    double countHandle = 0;///////////////
    setConsts(&avg, &std, &min);
    msgRecieveId = msgget(SORTER, 0666 | IPC_CREAT);

    while (msgrcv(msgRecieveId, &message, sizeof(message), 0, 0) != -1) {
        handleTime = initRandomByType(avg, std, min);
        countHandle += handleTime;
        usleep(handleTime); //todo: test this later
        customerKey = getType(message.msgText);
        msgForwardID = msgget(customerKey, 0666 | IPC_CREAT);
        message.msgType = 1;
        msgsnd(msgForwardID, &message, sizeof(message), 0);

        if (!strncmp(message.msgText, "QUIT", 4))
            break;
    }
    sendTerminalMsgs(&message);
    msgctl(msgRecieveId, IPC_RMID, NULL);

}

int main(int argc, char *argv[]) {
    start();

    return 0;
}