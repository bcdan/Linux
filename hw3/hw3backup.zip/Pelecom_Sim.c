

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include "random.h"
#include "stopwatch.h"
#include "Pelecom_Sim.h"
#include <unistd.h>


double initRandomByType(double avg, double std, double min) {
    initrand();

    int i;
    int size = 1000;

    double cnt;
    double x;
    double sum = 0;
    double ssq = 0;
    cnt = (double) size;
    for (i = 0; i < size; i++) {
        x = pnrand(avg, std, min);
        sum += x;
        ssq += x * x;
    }

    avg = sum / cnt;
    return avg;
}


char *generateCustomer(int *typeOfCustomer) {
    initrand();
    double num = 0;
    num = urand(1, 100);
    if (num < POP_NEW) {
        *typeOfCustomer = TYPE_NEW;
        return "NEW";
    } else if (num < POP_UPGRADE) {
        *typeOfCustomer = TYPE_UPGRADE;
        return "UPGRADE";
    } else {
        *typeOfCustomer = TYPE_REPAIR;
        return "REPAIR";
    }

}

void setArriveConsts(double *avg, double *std, double *min) {
    *avg = AVRG_ARRIVE;
    *std = SPRD_ARRIVE;
    *min = MIN_ARRIVE;
}

void gatherInfo(int type, long time) {
    message.msgType = 1;
    message.c.c_id = (long) numOfCustomers;
    message.c.c_data.type = (type + 100);
    message.c.c_data.enter_time = swlap(&sw[0]);
    message.c.c_data.start_time = message.c.c_data.enter_time + (time / 1000);
}

void initCustomers() {

    int msgid;
    int flag = TRUE;
    int _intType = -1;
    double avg;
    double std;
    double min;
    double handleTime;
    char *_strQueueType;
    long temp_time;

    setArriveConsts(&avg, &std, &min);
    while (TRUE) {
        handleTime = initRandomByType(avg, std, min);
        _strQueueType = generateCustomer(&_intType);
        msgid = msgget(SORTER, 0666 | IPC_CREAT);
        // gatherInfo(_intType, handleTime);
        message.msgType = 1;
        // printf("start time %ld\n", message.cus.c_data.start_time);
        temp_time = swlap(&sw[0]);
        if (temp_time > simTime * 1000) {
            printf("time to quit %ld", swlap(&sw[0]));
            // printf("Write Data : QUIT\n");
            sprintf(message.msgText, "%s", "QUIT\n");
            flag = FALSE;
        } else {
            // printf("Write Data : %s\n", agent);
            sprintf(message.msgText, "%s", _strQueueType);
        }
        //printf("Generated customer : %s \n", message.msgText);

        msgsnd(msgid, &message, sizeof(message), 0);
        numOfCustomers++;
        if (flag == FALSE) {
            break;
        }
        usleep(handleTime);
    }

}


void initProcs() {
    pid_t pid[NUMOFPROC];
    for (int i = 0; i < NUMOFPROC; i++) {
        if ((pid[i] = fork()) == 0) {
            execvp(*execFiles[i], execFiles[i]);
            perror("Execvp error");
            _exit(1);
        }
        if (pid[i] < 0) {
            perror("Fork error");
        }
    }

}


void checkQueues() {
    int i;
    key_t key;
    key = QUIT;
    int msgid;
    msgid = msgget(key, 0666 | IPC_CREAT);
    arr_client_msg = (struct message *) malloc(sizeof(struct message) * numOfCustomers);
    for (i = 0; i < numOfCustomers; i++) {
        // usleep(100000);
        // printf(" before id[%ld]: %s \n ",message.cus.c_id,message.mesg_text);
        msgrcv(msgid, &message, sizeof(message), 0, 0);
        arr_client_msg[i] = message;
    }

    for (i = 0; i < numOfCustomers; i++) {
        //usleep(100000);
        printf("[%d] msg is %s\n", i, arr_client_msg[i].msgText);

    }
}

void start() {

    initProcs();
    swstart(&sw[0]);
    initCustomers();
    checkQueues();
    free(arr_client_msg);
    printf("\n\n\n\n\n\nsize all %d\n\n\n\n\n", numOfCustomers);
    // wait(&status);
    // usleep(100000);
    // get_all_client();
    //finishTime = swlap(&sw[0]);
    printf("close the shop %ld", swlap(&sw[0]));
    // show_stats();
    // free_all_messages();
    printf("Ending-----\n");

}


int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Simulation time not entered, exiting...\n");
        return 0;

    }
    simTime = atoi(argv[1]);
    start();


    return 0;
}